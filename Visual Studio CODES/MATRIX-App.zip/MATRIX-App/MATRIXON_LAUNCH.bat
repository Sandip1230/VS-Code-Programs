@echo off
:: MATRIXON — One-Click Project Launcher
:: Double-click this file to launch your project

:: Start the Node.js server in background
start "" /B cmd /c "cd /d "%~dp0" && node server.js > server.log 2>&1"

:: Wait 1.5 seconds for server to boot
timeout /t 2 /nobreak >nul

:: Open index.html in default browser via localhost
start http://localhost:3000

:: Optional: keep server alive (close this window to stop server)
:: Remove the line below if you want it fully silent
:: pause
