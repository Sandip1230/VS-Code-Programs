/* ── CUSTOM TOAST NOTIFICATION ── */
function showToast(message, type) {
  // type: 'success' | 'error' | 'warn'
  let box = document.getElementById('matrixToastBox');
  if (!box) {
    box = document.createElement('div');
    box.id = 'matrixToastBox';
    box.style.cssText = 'position:fixed;top:24px;left:50%;transform:translateX(-50%);z-index:99999;display:flex;flex-direction:column;align-items:center;gap:10px;pointer-events:none;';
    document.body.appendChild(box);
  }
  const colors = {
    success: { border:'#00ff00', bg:'rgba(0,20,0,0.97)', icon:'✅', text:'#aaffaa' },
    error:   { border:'#ff4444', bg:'rgba(20,0,0,0.97)', icon:'❌', text:'#ffaaaa' },
    warn:    { border:'#ffcc00', bg:'rgba(20,15,0,0.97)', icon:'⚠️', text:'#ffeeaa' },
  };
  const c = colors[type] || colors.warn;
  const toast = document.createElement('div');
  toast.style.cssText = `
    background:${c.bg};border:1px solid ${c.border};border-radius:12px;
    padding:14px 24px;font-family:'Courier New',monospace;font-size:14px;
    color:${c.text};box-shadow:0 0 20px ${c.border}55;
    display:flex;align-items:center;gap:10px;pointer-events:auto;
    animation:toastSlideIn 0.4s cubic-bezier(.22,1,.36,1);
    min-width:260px;text-align:center;justify-content:center;letter-spacing:0.5px;
  `;
  toast.innerHTML = `<span>${c.icon}</span><span>${message}</span>`;
  // Inject keyframe once
  if (!document.getElementById('toastKeyframes')) {
    const s = document.createElement('style');
    s.id = 'toastKeyframes';
    s.textContent = '@keyframes toastSlideIn{from{opacity:0;transform:translateY(-16px)}to{opacity:1;transform:translateY(0)}}';
    document.head.appendChild(s);
  }
  box.appendChild(toast);
  setTimeout(() => {
    toast.style.transition = 'opacity 0.4s, transform 0.4s';
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(-10px)';
    setTimeout(() => toast.remove(), 400);
  }, 3000);
}

const morph = document.getElementById('morph');
const statusDot = document.getElementById('statusDot');
const statusText = document.getElementById('statusText');

/* ── AUTO-TYPE TITLE ── */
const titleEl = document.getElementById('autoType');
const titleStr = 'MATRIXON';
let ti = 0;
function typeTitle() {
  if (ti < titleStr.length) {
    titleEl.textContent += titleStr[ti++];
    setTimeout(typeTitle, 150);
  }
}
setTimeout(typeTitle, 400);

/* ── MORPH CLICK (power on) ── */
morph.addEventListener('click', function (e) {
  if (!morph.classList.contains('active')) {
    createParticles(e);
    setTimeout(function () {
      morph.classList.add('active');
      statusDot.classList.add('on');
      statusText.textContent = 'SYSTEM ONLINE — ENTER CREDENTIALS';
    }, 220);
  }
});

/* ── CLOSE FORM ── */
function closeForm(e) {
  e.stopPropagation();
  morph.classList.remove('active');
  statusDot.classList.remove('on');
  statusText.textContent = 'SYSTEM OFFLINE — PRESS POWER';
}

/* ── SHOW / HIDE PASSWORD ── */
function togglePassword() {
  const pwd = document.getElementById('password');
  const toggle = document.querySelector('.toggle');
  if (pwd.type === 'password') {
    pwd.type = 'text';
    toggle.textContent = 'Hide';
  } else {
    pwd.type = 'password';
    toggle.textContent = 'Show';
  }
}

/* ── GREEN PARTICLE BURST ── */
function createParticles(e) {
  const rect = morph.getBoundingClientRect();
  const cx = rect.left + rect.width / 2;
  const cy = rect.top + rect.height / 2;
  const colors = ['#00ff00', '#00cc44', '#00ff88', '#33ff66', '#aaffaa', '#ffffff'];
  for (let i = 0; i < 60; i++) {
    const p = document.createElement('div');
    p.className = 'particle';
    const angle = Math.random() * 360;
    const radius = 60 + Math.random() * 180;
    const xMove = Math.cos(angle * Math.PI / 180) * radius;
    const yMove = Math.sin(angle * Math.PI / 180) * radius;
    const size = 4 + Math.random() * 6;
    const color = colors[Math.floor(Math.random() * colors.length)];
    p.style.cssText = `
      left: ${cx}px; top: ${cy}px;
      width: ${size}px; height: ${size}px;
      background: ${color}; box-shadow: 0 0 6px ${color};
      --x: ${xMove}px; --y: ${yMove}px;
    `;
    document.body.appendChild(p);
    setTimeout(function () { p.remove(); }, 1000);
  }
}

/* ── LOGIN ── */
document.getElementById('accessBtn').addEventListener('click', function () {
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value;
  if (!username || !password) { showToast('Enter Username and Password', 'warn'); return; }

  fetch('http://localhost:3000/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  })
  .then(function (r) { return r.json(); })
  .then(function (data) {
    if (data.success) {
      /* ✅ Save username to localStorage so all pages know who is logged in */
      localStorage.setItem('matrixon_user', username);

      /* Setup profile (creates UID + nickname if first login) */
      fetch('http://localhost:3000/profile/setup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username })
      }).finally(function () {
        const countrySet = localStorage.getItem('matrixon_country_set');

        if (!countrySet) {
          // New user → select country first
          window.location.href = 'country-select.html';
        } else {
          // Existing user → go to learning
          window.location.href = 'learning.html';
        }
      });
    } else {
      showToast('Invalid Username or Password', 'error');
    }
  })
  .catch(function () { showToast('Server not reachable', 'error'); });
});

/* ── REGISTER ── */
document.getElementById('registerBtn').addEventListener('click', function () {
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value;
  if (!username || !password) { showToast('Enter Username and Password', 'warn'); return; }

  fetch('http://localhost:3000/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  })
  .then(function (r) { return r.json(); })
  .then(function (data) {
    if (data.success) {
      showToast('Registered! You can now login.', 'success');
    } else {
      showToast('Registration Failed — username may already exist.', 'error');
    }
  })
  .catch(function () { showToast('Server not reachable', 'error'); });
});